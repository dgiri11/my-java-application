package com.example.demo.functional;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FunctionalProgrammingPracticesApplicationTests {

	@Test
	void contextLoads() {
	}

}
