package com.example.demo.functional;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FunctionalProgrammingPracticesApplication {

	public static void main(String[] args) {
		SpringApplication.run(FunctionalProgrammingPracticesApplication.class, args);
	}

}
