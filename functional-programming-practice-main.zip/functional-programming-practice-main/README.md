# functional-programming-practice
functional-programming-practice in java using java 8 and higher version
